import torch
import numpy as np
import matplotlib.pyplot as plt
from DataSet import *

def plotting(test_loader, model):
  with torch.no_grad():
      test_pred = []
      targetting = []
      for data in test_loader:
          seq, target = data 
          out = model(seq)
          print(out.size())
          targetting += target.cpu().numpy().tolist()
          test_pred += out.cpu().numpy().round().tolist()
          
      actual = targetting
      total = test_pred       

      # #plot
      # plt.figure(figsize=(40,10))
      
      # #signal
      # plt.plot(actual[:],'b')
      # plt.plot(total[:],'r', linewidth=0.6)
      # plt.legend(['actual','prediction'])
      # plt.show()

      t=np.array(actual[:])
      l=np.array(total[:])
      
      correct=0
      uncorrect=0
      FP=0;TP=0;FN=0;TN=0
      
      for i, j in zip(t, l):
          if(i-j==0):
              correct=correct+1
              if(j==1):TP=TP+1
              else:TN=TN+1
          else: 
              uncorrect=uncorrect+1
              if(j==1):FP=FP+1
              else:FN=FN+1
      
      all=correct+uncorrect
      acc=correct/all
      
      #accuracy (classification)
      print("\n----------------------------------------------")
      print('the number of correct', correct)
      print('the number of uncorrect', uncorrect)

      print("\n"+"confusion matrix")
      print("TP: "+str(TP))
      print("TN: "+str(TN))
      print("FP: "+str(FP)) 
      print("FN: "+str(FN))

      print('\n'+'accuracy:', acc)

def plottingperMap(test_features, test_labels, model):
    with torch.no_grad():
        test_pred = []
        targetting = []

        seq = test_features
        target = test_labels
        out = model(seq)
        print(out.size())
        targetting += target.cpu().numpy().tolist()
        test_pred += out.cpu().numpy().round().tolist()
        
        actual = targetting
        total = test_pred       

        #plot
        plt.figure(figsize=(40,10))
        
        #signal
        plt.plot(actual[:],'b')
        plt.plot(total[:],'r', linewidth=0.6)
        plt.legend(['actual','prediction'])
        #plt.show()

        t=np.array(actual[:])
        l=np.array(total[:])
        
        correct=0
        uncorrect=0
        FP=0;TP=0;FN=0;TN=0
        
        for i, j in zip(t, l):
            if(i-j==0):
                correct=correct+1
                if(j==1):TP=TP+1
                else:TN=TN+1
            else: 
                uncorrect=uncorrect+1
                if(j==1):FP=FP+1
                else:FN=FN+1
        
        all=correct+uncorrect
        acc=correct/all
        
        #accuracy (classification)
        print("\n----------------------------------------------")
        print('the number of correct', correct)
        print('the number of uncorrect', uncorrect)

        print("\n"+"confusion matrix")
        print("TP: "+str(TP))
        print("TN: "+str(TN))
        print("FP: "+str(FP)) 
        print("FN: "+str(FN))

        print('\n'+'accuracy:', acc)


def plottingperUE(One_test_features, One_test_labels, model):
    with torch.no_grad():
        test_pred = []
        targetting = []

        seq = One_test_features
        target = One_test_labels
        out = model(seq)
        targetting += target.cpu().numpy().tolist()
        test_pred += out.cpu().numpy().round().tolist()
        
        actual = targetting
        total = test_pred       

        #plot
        plt.figure(figsize=(40,10))
        
        #signal
        plt.plot(actual[:],'b')
        plt.plot(total[:],'r', linewidth=0.6)
        plt.legend(['actual','prediction'])
        plt.show()

        t=np.array(actual[:])
        l=np.array(total[:])
        correct=0
        uncorrect=0
        FP=0;TP=0;FN=0;TN=0
        
        for i, j in zip(t, l):
            if(i-j==0):
                correct=correct+1
                if(j==1):TP=TP+1
                else:TN=TN+1
            else: 
                uncorrect=uncorrect+1
                if(j==1):FP=FP+1
                else:FN=FN+1
        
        all=correct+uncorrect
        acc=correct/all
        
        #accuracy (classification)
        print("\n----------------------------------------------")
        print('the number of correct', correct)
        print('the number of uncorrect', uncorrect)

        print("\n"+"confusion matrix")
        print("TP: "+str(TP))
        print("TN: "+str(TN))
        print("FP: "+str(FP)) 
        print("FN: "+str(FN))

        print('\n'+'accuracy:', acc)
        
        # correlation_coefficient = np.corrcoef(t, l)

        # print("\nCorrelation Coefficient\n", correlation_coefficient)
        # print('Correlation Coefficient:', correlation_coefficient[1][0]*100)