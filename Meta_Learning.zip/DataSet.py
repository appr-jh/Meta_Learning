import torch
import random
import numpy as np
import pandas as pd
import torch.nn as nn
from parameter import *

def load_data():
    pl = pd.read_table(f'C:/Users/DCLAB/Desktop/Dataset/dataset.csv', sep=',')
    X = pl[["Realized_Power"]].values
    y = pl["Real_block"].values
    return X, y

# seq_data
def seq_data(x, y, seq_len): # sequence length
    X_seq = []
    y_seq = []
    
    for i in range(len(x)-SaturationForRange):
            X_seq.append(x[i:i+seq_len])
            y_seq.append(y[i+seq_len+1])

    X_seq = np.array(X_seq)        
    y_seq = np.array(y_seq)

    return torch.FloatTensor(X_seq).to(device), torch.FloatTensor(y_seq).to(device).view([-1, 1]) 

def train_test_seperate(X, y, seq_len, split, batch_size):
    X_seq, y_seq = seq_data(X, y, seq_len)
    X_train_seq = X_seq[:split]
    y_train_seq = y_seq[:split]
    X_test_seq = X_seq[split:]
    y_test_seq = y_seq[split:]

    # Dataset
    train = torch.utils.data.TensorDataset(X_train_seq, y_train_seq)
    test  = torch.utils.data.TensorDataset(X_test_seq, y_test_seq)

    # Dataloader -> batch_size
    train_loader = torch.utils.data.DataLoader(dataset=train, batch_size=batch_size, shuffle=False)
    test_loader  = torch.utils.data.DataLoader(dataset=test, batch_size=batch_size, shuffle=False)

    return train_loader, test_loader

def sample_data(x, y, seq_len, FewShotDataNum):
    x_seq = []
    y_seq = []
    
    RandomDataSetIdx = random.randint(0, 5) # 0 <= x <= 5
    #range limit X, y (random * 998400)
    #random * 998400 ~ random * 998400 + 998400 - 21 (offset=seq_len+(x_n+1))
    Idx_RangeX = RandomDataSetIdx * SAMPLE_NUM
    Idx_RangeY = Idx_RangeX + SAMPLE_NUM - SaturationForRange - FewShotDataNum
    #Random location per 1 random Map
    RandomDataSetloc = random.randint(Idx_RangeX, Idx_RangeY)

    RangeX = RandomDataSetloc
    RangeY = RandomDataSetloc + FewShotDataNum
    
    for i in range(RangeX, RangeY):
            x_seq.append(x[i:i+seq_len])
            y_seq.append(y[i+seq_len+1])

    x_seq = np.array(x_seq)        
    y_seq = np.array(y_seq)

    return torch.FloatTensor(x_seq).to(device), torch.FloatTensor(y_seq).to(device).view([-1, 1]) 

def Test_data(x, y, seq_len):
    x_seq = []
    y_seq = []

    RandomDataSetIdx = random.randint(6, 7)     #not hidden size -> map dataset (8)
    RandomDataSetloc = SAMPLE_NUM * RandomDataSetIdx
    
    RangeX = RandomDataSetloc
    RangeY = SAMPLE_NUM + RandomDataSetloc# - SaturationForRange

    for i in range(RangeX, RangeY):
            x_seq.append(x[i:i+seq_len])
            y_seq.append(y[i+seq_len+1])

    x_seq = np.array(x_seq)        
    y_seq = np.array(y_seq)

    return torch.FloatTensor(x_seq).to(device), torch.FloatTensor(y_seq).to(device).view([-1, 1]) 

def One_Test_data(x, y, seq_len):
    x_seq = []
    y_seq = []

    RandomDataSetIdx = random.randint(6, 8)                     # not hidden size -> map dataset (8)
    RandomDataResultIdx = random.randint(0, 99)                 # 100 result per map
    RandomDataSetloc = BATCH_SIZE * RandomDataSetIdx * RandomDataResultIdx

    RangeX = RandomDataSetloc
    RangeY = BATCH_SIZE + RandomDataSetloc# - SaturationForRange

    for i in range(RangeX, RangeY):
            x_seq.append(x[i:i+seq_len])
            y_seq.append(y[i+seq_len+1])

    x_seq = np.array(x_seq)        
    y_seq = np.array(y_seq)

    return torch.FloatTensor(x_seq).to(device), torch.FloatTensor(y_seq).to(device).view([-1, 1]) 