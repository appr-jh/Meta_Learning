import torch
import matplotlib.pyplot as plt
from parameter import *
from DataSet import *
from plot_function import *


#predict 1Map
X, y = load_data()
test_features, test_labels = Test_data(X, y, SEQ_LEN)

model = torch.load("model/model.pt")
pretrained_model = torch.load("model/pre_model.pt")

plottingperMap(test_features, test_labels, model)
plottingperMap(test_features, test_labels, pretrained_model)

plt.show()