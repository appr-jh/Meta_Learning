import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import math

from torch.autograd import Variable
from parameter import *

class LSTMCell(nn.Module) :
    def __init__(self, input_size, hidden_size, bias=True) :
        super(LSTMCell, self).__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.bias = bias
        self.x2h = nn.Linear(input_size, 4*hidden_size, bias=bias) 
        self.h2h = nn.Linear(hidden_size, 4*hidden_size, bias=bias)
        self.reset_parameters()
        
    def reset_parameters(self) :
        std = 1.0 / math.sqrt(self.hidden_size)
        for w in self.parameters() :
            w.data.uniform_(-std, std)
            
    def forward(self, x, hidden_size) :
        hx, cx = hidden_size
        x = x.view(-1, x.size(1))
        
        gates = self.x2h(x) + self.h2h(hx)
        gates = gates.squeeze()
        InputGate, ForgetGate, CellGate, OutGate = gates.chunk(4, -1)
        
        InputGate = F.sigmoid(InputGate)          
        ForgetGate = F.sigmoid(ForgetGate)  
        CellGate = F.tanh(CellGate)         
        OutGate = F.sigmoid(OutGate)        
        
        # cy = ForgetGate * cx + InputGate *  CellGate
        cy = torch.mul(cx, ForgetGate) + torch.mul(InputGate, CellGate)
        hy = torch.mul(OutGate, F.tanh(cy))
        
        return (hy, cy)
    
class MAMLModel(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, device, num_classes, seq_len):
        super(MAMLModel, self).__init__()
        self.input_size = input_size
        self.device = device
        self.hidden_size = hidden_size
        self.seq_len = seq_len
        self.num_layers = num_layers
        self.lstm = nn.LSTMCell(input_size, hidden_size)
        self.fc = nn.Linear(hidden_size*seq_len, num_classes) #hidden size per length
        self.sigmoid = nn.Sigmoid()
        
    def forward(self, x):
        Initial_HiddenState = Variable(torch.Tensor(torch.zeros(self.num_layers, x.size(0), self.hidden_size))).to(device)
        Initial_CellState = Variable(torch.Tensor(torch.zeros(self.num_layers, x.size(0), self.hidden_size))).to(device)

        out = []
        CellState = Initial_CellState[0,:,:]
        HiddenState = Initial_HiddenState[0,:,:]
    
        for seq in range(x.size(1)) :
            HiddenState, CellState = self.lstm(x[:, seq, :], (HiddenState, CellState))
            out.append(HiddenState.unsqueeze(1))
        
        out = torch.cat(out, dim=1) #10, 20, 8
        out = out.reshape(out.shape[0], -1)
        out = self.fc(out)
        out = self.sigmoid(out)
        return out
    
    # FewshotDataset -> initial point
    def parameterised(self, x, weights):
        InputGate_Weight, ForgetGate_Weight, CellGate_Weight, OutputGate_Weight = weights[0].split(8, dim=0)
        InputGate_bias, ForgetGate_bias, CellGate_bias, OutputGate_bias = weights[2].split(8, dim=0)

        InputGate_HiddenWeight, ForgetGate_HiddenWeight, CellGate_HiddenWeight, OutputGate_HiddenWeight = weights[1].split(8, dim=0)
        InputgetGate_HiddenBias, ForgetGate_HiddenBias, CellGate_HiddenBias, OutputGate_HiddenBias = weights[3].split(8, dim=0)

        Initial_HiddenState = Variable(torch.Tensor(torch.zeros(self.num_layers, x.size(0), self.hidden_size))).to(device)
        Initial_CellState = Variable(torch.Tensor(torch.zeros(self.num_layers, x.size(0), self.hidden_size))).to(device)
        CellState = Initial_CellState[0,:,:]
        HiddenState = Initial_HiddenState[0,:,:]

        out = []
        for seq in range(x.size(1)):
            InputGate = torch.sigmoid(F.linear(x[:, seq, :], InputGate_Weight, InputGate_bias) 
                                      + F.linear(HiddenState, InputGate_HiddenWeight, InputgetGate_HiddenBias))
            ForgetGate = torch.sigmoid(F.linear(x[:, seq, :], ForgetGate_Weight, ForgetGate_bias) 
                                       + F.linear(HiddenState, ForgetGate_HiddenWeight, ForgetGate_HiddenBias))
            CellGate = torch.tanh(F.linear(x[:, seq, :], CellGate_Weight, CellGate_bias) 
                                  + F.linear(HiddenState, CellGate_HiddenWeight, CellGate_HiddenBias))
            OutputGate = torch.sigmoid(F.linear(x[:, seq, :], OutputGate_Weight, OutputGate_bias) 
                                       + F.linear(HiddenState, OutputGate_HiddenWeight, OutputGate_HiddenBias))
            CellState = ForgetGate * CellState + InputGate * CellGate
            HiddenState = OutputGate * torch.tanh(CellState) # (10, 8) x 20
            out.append(HiddenState.unsqueeze(1))

        out = torch.cat(out, dim=1) #10, 20, 8
        out = out.reshape(out.shape[0], -1)
        x = F.linear(out, weights[4], weights[5]) #(9984, 20, 8) -> (9984, 160) * (160, 1) => (9984, 1)
        x = torch.sigmoid(x)

        return x
