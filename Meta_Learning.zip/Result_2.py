import torch
from parameter import *
from DataSet import *
from plot_function import *

# predict 7map, 8map
X, y = load_data()
train_loader, test_loader = train_test_seperate(X, y, SEQ_LEN, SPLIT, BATCH_SIZE)

model = torch.load("model/model.pt")
pretrained_model = torch.load("model/pre_model.pt")

plotting(test_loader, model)
plotting(test_loader, pretrained_model)