import matplotlib.pyplot as plt
import torch
import torch.nn as nn
import numpy as np
from DataSet import *
from Cell import *

def model_training(train_loader, num_epochs, model, criterion, optimizer): 
    loss_graph = []
    n = len(train_loader)

    for epoch in range(num_epochs): # epoch
        running_loss = 0.0  
        
        for i, data in enumerate(train_loader): # batch 
            seq, target = data
            out = model(seq)
            loss = criterion(out, target)
            
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            running_loss += loss.item()
        
        loss_graph.append(running_loss/n)
        
        if epoch % 10 == 0:
            print('[epoch: %d] loss: %.8f' %(epoch, running_loss/n))
    
    plt.figure(figsize=(20,10))
    plt.plot(loss_graph)

class MAML():
    def __init__(self, model, criterion, inner_lr, meta_lr,
                 K=10, inner_steps=1, tasks_per_meta_batch=10):
        
        # important objects
        self.model = model
        self.weights = list(model.parameters()) # the maml weights we will be meta-optimising
        self.meta_optimiser = torch.optim.Adam(self.weights, meta_lr)
        self.criterion = CRITERION

        # hyperparameters
        self.inner_lr = inner_lr
        self.meta_lr = meta_lr
        self.K = K
        self.inner_steps = inner_steps # with the current design of MAML, >1 is unlikely to work well 
        self.tasks_per_meta_batch = tasks_per_meta_batch 
        
        # metrics
        self.plot_every = 100
        self.print_every = 1000
        self.meta_losses = []
    
    # Meta Learning
    def inner_loop(self):
        # reset inner model to current maml weights
        temp_weights = [w.clone() for w in self.weights]
        X, y = load_data()
        X, y = sample_data(X, y, SEQ_LEN, self.K)

        # perform training on data sampled from 5 task
        for step in range(10):
            loss = self.criterion(self.model.parameterised(X, temp_weights), y) / self.K
            # compute grad and update inner loop weights
            grad = torch.autograd.grad(loss, temp_weights, allow_unused=True) #True extremely important
            modified_tuple = tuple(0 if item is None else item for item in grad)
            temp_weights = [w - self.inner_lr * g for w, g in zip(temp_weights, modified_tuple)]
        self.weights = temp_weights
    
    def main_loop(self, num_iterations):
        epoch_loss = 0
        meta_loss = 0
        X, y = load_data()

        # inner_loop -> meta learning (Few-shot dataset)
        for i in range(self.tasks_per_meta_batch):
            self.inner_loop()
            
        for iteration in range(1, num_iterations+1):
            seq, taget = sample_data(X, y, SEQ_LEN, self.K)
            out = self.model(seq)
            meta_loss = self.criterion(out, taget) / self.K
            self.model.zero_grad()
            meta_loss.backward()
            self.meta_optimiser.step()
                    
            # log metrics
            epoch_loss += meta_loss.item() / self.tasks_per_meta_batch

            if iteration % self.print_every == 0:
                print("{}/{}. loss: {}".format(iteration, num_iterations, epoch_loss / self.plot_every))
            
            if iteration % self.plot_every == 0:
                self.meta_losses.append(epoch_loss / self.plot_every)
                epoch_loss = 0

def mixed_pretrained(X, y, iterations=500, K=10):
    """
    returns a model pretrained on a selection of ``iterations`` random tasks.
    """
    X, y = load_data()
    
    # set up model
    pretrain_model = MAMLModel(input_size=INPUT_SIZE, 
                   hidden_size=HIDDEN_SIZE, 
                   num_layers=NUM_LAYERS, 
                   num_classes=NUM_CLASSES,
                   seq_len=SEQ_LEN, 
                   device=device).to(device)
    
    optimiser = torch.optim.Adam(pretrain_model.parameters(), lr=0.01)
    criterion = nn.MSELoss()

    # fit the model
    for i in range(iterations):
        seq, target = sample_data(X, y, SEQ_LEN, K)
        out = pretrain_model(seq)
        #print(seq, target) = feature, label
        loss = criterion(out, target) 
        pretrain_model.zero_grad()
        loss.backward()
        optimiser.step()
        
    return pretrain_model