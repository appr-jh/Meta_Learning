import torch
from parameter import *
from ResultFunc_1 import *
from DataSet import *
import matplotlib.pyplot as plt

K = 20
X, y = load_data()
seq, target = sample_data(X, y, SEQ_LEN, K)

model = torch.load("model/model.pt")
pretrained_model = torch.load("model/pre_model.pt")

plot_sampled_performance(model, 'MAML', seq, target, K)
plot_sampled_performance(pretrained_model, 'pretrained at lr=0.01', seq, target, K)

K=10
seq, target = sample_data(X, y, SEQ_LEN, K)
plot_sampled_performance(model, 'MAML', seq, target, K)
plot_sampled_performance(pretrained_model, 'pretrained at lr=0.01', seq, target, K)

K=5
seq, target = sample_data(X, y, SEQ_LEN, K)
plot_sampled_performance(model, 'MAML', seq, target, K)
plot_sampled_performance(pretrained_model, 'pretrained at lr=0.01', seq, target, K)

plt.show()