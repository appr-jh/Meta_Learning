import torch
import matplotlib.pyplot as plt
from parameter import *
from DataSet import *
from plot_function import *


#predict UE - UAV
X, y = load_data()
One_test_features, One_test_labels = One_Test_data(X, y, SEQ_LEN)

model = torch.load("model/model.pt")
pretrained_model = torch.load("model/pre_model.pt")

plottingperUE(One_test_features, One_test_labels, model)
plottingperUE(One_test_features, One_test_labels, pretrained_model)

plt.show()