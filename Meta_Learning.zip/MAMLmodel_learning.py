import os
import math
import random
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.autograd import Variable

from Learning_Function import *
from DataSet import *
from Cell import *

#MODEL PARAMETER
DATA_OFFSET     = 1                                                 # data preprocess offset
INPUT_SIZE      = 1                                                 # the number of input data feature
NUM_LAYERS      = 1                                                 # staked RNN
HIDDEN_SIZE     = 8                                                 # hidden layer 8
NUM_CLASSES     = 1                                                 # the number of output data feature

# HYPERPARAMETER
SEQ_LEN         = 20                                                # sequence length
BATCH_SIZE      = 9984                                              # batch size (32 * 312)
CRITERION       = nn.MSELoss()                                      # mean square error
LEARNING_RATE   = 1e-3                                              # learning rate
NUM_EPOCHS      = 100                                               # epoch

#DATA PARAMETER
TRAIN_NUM          = 600                                            # train number == #iteration -> 6 set
TEST_NUM           = 200                                            # test number                 -> 
DATASET_NUM        = TRAIN_NUM + TEST_NUM                           # dataset number (800)

# PlOT PARAMETER
SET_NUM         = 9984                                              # set size
SAMPLE_PER_SET  = 100                                               # sample size per set
SAMPLE_NUM      = SET_NUM * SAMPLE_PER_SET                          # sample: 998,400
TEST_SIZE       = SET_NUM * TEST_NUM                                # test size (9984 * 180)
SPLIT           = SET_NUM * DATASET_NUM - TEST_SIZE                 # plot test number (9984 * 800 - 9984 * 200) = train number

#Data local parameter
SaturationForRange = SEQ_LEN + DATA_OFFSET                          # prevent idx error

#device
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print(f'{device} is available.')

#train, test dataset
X, y = load_data()

train_loader, test_loader = train_test_seperate(X, y, SEQ_LEN, SPLIT, BATCH_SIZE)

model = MAMLModel(input_size=INPUT_SIZE, 
                   hidden_size=HIDDEN_SIZE, 
                   num_layers=NUM_LAYERS, 
                   num_classes=NUM_CLASSES,
                   seq_len=SEQ_LEN, 
                   device=device).to(device)

maml = MAML(model, CRITERION, inner_lr=0.001, meta_lr=0.001)

maml.main_loop(num_iterations=10000)

torch.save(model, 'model/model.pt')
print("successful complete")
#model = torch.load('C:/Users/DCLAB/Desktop/model.pt')